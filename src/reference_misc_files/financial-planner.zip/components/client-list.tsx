"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { SearchIcon } from "lucide-react"

// Mock data for demonstration
const MOCK_CLIENTS = [
  {
    id: "1",
    name: "John Smith",
    email: "john.smith@example.com",
    age: 45,
    totalAssets: "$1,250,000",
    lastContact: "2023-06-15",
  },
  {
    id: "2",
    name: "Sarah Johnson",
    email: "sarah.j@example.com",
    age: 38,
    totalAssets: "$780,000",
    lastContact: "2023-06-20",
  },
  {
    id: "3",
    name: "Michael Brown",
    email: "m.brown@example.com",
    age: 52,
    totalAssets: "$2,100,000",
    lastContact: "2023-06-10",
  },
  {
    id: "4",
    name: "Emily Davis",
    email: "emily.d@example.com",
    age: 41,
    totalAssets: "$950,000",
    lastContact: "2023-06-18",
  },
  {
    id: "5",
    name: "Robert Wilson",
    email: "r.wilson@example.com",
    age: 60,
    totalAssets: "$3,500,000",
    lastContact: "2023-06-05",
  },
]

export function ClientList() {
  const [searchQuery, setSearchQuery] = useState("")

  const filteredClients = MOCK_CLIENTS.filter(
    (client) =>
      client.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      client.email.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Clients</CardTitle>
            <CardDescription>Manage your client portfolio</CardDescription>
          </div>
          <Button asChild variant="outline">
            <Link href="/dashboard/add-client">Add Client</Link>
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-4 flex items-center gap-2">
          <div className="relative flex-1">
            <SearchIcon className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search clients..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Age</TableHead>
                <TableHead>Total Assets</TableHead>
                <TableHead>Last Contact</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredClients.map((client) => (
                <TableRow key={client.id}>
                  <TableCell className="font-medium">
                    <div>{client.name}</div>
                    <div className="text-sm text-muted-foreground">{client.email}</div>
                  </TableCell>
                  <TableCell>{client.age}</TableCell>
                  <TableCell>{client.totalAssets}</TableCell>
                  <TableCell>{client.lastContact}</TableCell>
                  <TableCell className="text-right">
                    <Button asChild variant="ghost" size="sm">
                      <Link href={`/dashboard/clients/${client.id}`}>View</Link>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {filteredClients.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="h-24 text-center">
                    No clients found.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
