"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { DollarSignIcon, HomeIcon, PiggyBankIcon } from "lucide-react"
import { DatePicker } from "@/components/date-picker"

export function AddClientForm() {
  const router = useRouter()
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [dateOfBirth, setDateOfBirth] = useState<Date | undefined>(undefined)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // In a real app, this would submit the form data to an API
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "Client added successfully",
        description: "The new client has been added to your portfolio",
      })

      router.push("/dashboard")
    } catch (error) {
      toast({
        title: "Error adding client",
        description: "There was a problem adding the client. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <Tabs defaultValue="personal" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="personal">Personal Info</TabsTrigger>
          <TabsTrigger value="financial">Financial</TabsTrigger>
          <TabsTrigger value="investments">Investments</TabsTrigger>
          <TabsTrigger value="retirement">Retirement</TabsTrigger>
        </TabsList>

        <TabsContent value="personal" className="space-y-4 pt-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="first-name">First Name</Label>
              <Input id="first-name" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="last-name">Last Name</Label>
              <Input id="last-name" required />
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input id="phone" type="tel" />
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="dob">Date of Birth</Label>
              <DatePicker date={dateOfBirth} setDate={setDateOfBirth} className="w-full" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="occupation">Occupation</Label>
              <Input id="occupation" />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="address">Address</Label>
            <Textarea id="address" rows={3} />
          </div>
        </TabsContent>

        <TabsContent value="financial" className="space-y-4 pt-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="annual-income">Annual Income</Label>
              <div className="relative">
                <DollarSignIcon className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input id="annual-income" type="number" className="pl-9" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="tax-bracket">Current Tax Bracket (%)</Label>
              <Input id="tax-bracket" type="number" min="0" max="100" />
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="total-savings">Total Savings</Label>
              <div className="relative">
                <DollarSignIcon className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input id="total-savings" type="number" className="pl-9" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="total-debt">Total Debt</Label>
              <div className="relative">
                <DollarSignIcon className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input id="total-debt" type="number" className="pl-9" />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="financial-goals">Financial Goals</Label>
            <Textarea id="financial-goals" rows={3} placeholder="Retirement at 65, college funds for children, etc." />
          </div>
        </TabsContent>

        <TabsContent value="investments" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <HomeIcon className="mr-2 h-5 w-5 text-green-600" />
                Real Estate Investments
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="property-value">Property Value</Label>
                  <div className="relative">
                    <DollarSignIcon className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input id="property-value" type="number" className="pl-9" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="mortgage-balance">Mortgage Balance</Label>
                  <div className="relative">
                    <DollarSignIcon className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input id="mortgage-balance" type="number" className="pl-9" />
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="property-details">Property Details</Label>
                <Textarea id="property-details" rows={2} placeholder="Address, type of property, etc." />
              </div>
              <Button type="button" variant="outline" size="sm">
                + Add Another Property
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <PiggyBankIcon className="mr-2 h-5 w-5 text-green-600" />
                Other Investments
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="stocks-value">Stocks & Bonds</Label>
                  <div className="relative">
                    <DollarSignIcon className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input id="stocks-value" type="number" className="pl-9" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="other-investments">Other Investments</Label>
                  <div className="relative">
                    <DollarSignIcon className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input id="other-investments" type="number" className="pl-9" />
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="investment-details">Investment Details</Label>
                <Textarea id="investment-details" rows={2} placeholder="Types of investments, risk tolerance, etc." />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="retirement" className="space-y-4 pt-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="retirement-age">Expected Retirement Age</Label>
              <Input id="retirement-age" type="number" min="50" max="100" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="retirement-income">Desired Monthly Retirement Income</Label>
              <div className="relative">
                <DollarSignIcon className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input id="retirement-income" type="number" className="pl-9" />
              </div>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">401(k) Accounts</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="401k-balance">Current 401(k) Balance</Label>
                  <div className="relative">
                    <DollarSignIcon className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input id="401k-balance" type="number" className="pl-9" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="401k-contribution">Annual Contribution</Label>
                  <div className="relative">
                    <DollarSignIcon className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input id="401k-contribution" type="number" className="pl-9" />
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="401k-details">Account Details</Label>
                <Textarea id="401k-details" rows={2} placeholder="Provider, employer match, etc." />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">IRA Accounts</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="ira-type">IRA Type</Label>
                  <select id="ira-type" className="w-full rounded-md border border-input bg-background px-3 py-2">
                    <option value="traditional">Traditional IRA</option>
                    <option value="roth">Roth IRA</option>
                    <option value="both">Both</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="ira-balance">Current IRA Balance</Label>
                  <div className="relative">
                    <DollarSignIcon className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input id="ira-balance" type="number" className="pl-9" />
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="ira-details">Account Details</Label>
                <Textarea id="ira-details" rows={2} placeholder="Provider, contribution history, etc." />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="mt-6 flex justify-end space-x-4">
        <Button type="button" variant="outline" onClick={() => router.push("/dashboard")}>
          Cancel
        </Button>
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? "Saving..." : "Save Client"}
        </Button>
      </div>
    </form>
  )
}
