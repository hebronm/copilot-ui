import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CalendarIcon, DollarSignIcon, PiggyBankIcon } from "lucide-react"

// Mock data for demonstration
const CLIENT_DATA = {
  "1": {
    name: "John Smith",
    email: "john.smith@example.com",
    age: 45,
    occupation: "Software Engineer",
    address: "123 Main St, Anytown, CA 94123",
    annualIncome: "$120,000",
    taxBracket: "24%",
    totalAssets: "$1,250,000",
    totalDebt: "$320,000",
    lastContact: "2023-06-15",
    nextMeeting: "2023-07-10",
  },
  "2": {
    name: "Sarah Johnson",
    email: "sarah.j@example.com",
    age: 38,
    occupation: "Marketing Director",
    address: "456 Oak Ave, Somewhere, NY 10001",
    annualIncome: "$95,000",
    taxBracket: "22%",
    totalAssets: "$780,000",
    totalDebt: "$210,000",
    lastContact: "2023-06-20",
    nextMeeting: "2023-07-15",
  },
  "3": {
    name: "Michael Brown",
    email: "m.brown@example.com",
    age: 52,
    occupation: "Physician",
    address: "789 Pine St, Elsewhere, TX 75001",
    annualIncome: "$250,000",
    taxBracket: "35%",
    totalAssets: "$2,100,000",
    totalDebt: "$450,000",
    lastContact: "2023-06-10",
    nextMeeting: "2023-07-05",
  },
  "4": {
    name: "Emily Davis",
    email: "emily.d@example.com",
    age: 41,
    occupation: "Attorney",
    address: "101 Maple Dr, Nowhere, IL 60601",
    annualIncome: "$180,000",
    taxBracket: "32%",
    totalAssets: "$950,000",
    totalDebt: "$280,000",
    lastContact: "2023-06-18",
    nextMeeting: "2023-07-12",
  },
  "5": {
    name: "Robert Wilson",
    email: "r.wilson@example.com",
    age: 60,
    occupation: "Business Owner",
    address: "202 Cedar Ln, Anywhere, FL 33101",
    annualIncome: "$350,000",
    taxBracket: "37%",
    totalAssets: "$3,500,000",
    totalDebt: "$520,000",
    lastContact: "2023-06-05",
    nextMeeting: "2023-07-01",
  },
}

export function ClientOverview({ clientId }: { clientId: string }) {
  const client = CLIENT_DATA[clientId as keyof typeof CLIENT_DATA] || CLIENT_DATA["1"]

  return (
    <div className="space-y-6 pt-4">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Assets</CardTitle>
            <DollarSignIcon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{client.totalAssets}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Annual Income</CardTitle>
            <DollarSignIcon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{client.annualIncome}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tax Bracket</CardTitle>
            <PiggyBankIcon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{client.taxBracket}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Next Meeting</CardTitle>
            <CalendarIcon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{client.nextMeeting}</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Personal Information</CardTitle>
          </CardHeader>
          <CardContent>
            <dl className="space-y-4">
              <div className="flex justify-between">
                <dt className="font-medium text-muted-foreground">Full Name</dt>
                <dd>{client.name}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="font-medium text-muted-foreground">Email</dt>
                <dd>{client.email}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="font-medium text-muted-foreground">Age</dt>
                <dd>{client.age}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="font-medium text-muted-foreground">Occupation</dt>
                <dd>{client.occupation}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="font-medium text-muted-foreground">Address</dt>
                <dd>{client.address}</dd>
              </div>
            </dl>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Financial Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <dl className="space-y-4">
              <div className="flex justify-between">
                <dt className="font-medium text-muted-foreground">Annual Income</dt>
                <dd>{client.annualIncome}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="font-medium text-muted-foreground">Tax Bracket</dt>
                <dd>{client.taxBracket}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="font-medium text-muted-foreground">Total Assets</dt>
                <dd>{client.totalAssets}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="font-medium text-muted-foreground">Total Debt</dt>
                <dd>{client.totalDebt}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="font-medium text-muted-foreground">Net Worth</dt>
                <dd>
                  $
                  {(
                    Number.parseInt(client.totalAssets.replace(/[^0-9]/g, "")) -
                    Number.parseInt(client.totalDebt.replace(/[^0-9]/g, ""))
                  ).toLocaleString()}
                </dd>
              </div>
            </dl>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
