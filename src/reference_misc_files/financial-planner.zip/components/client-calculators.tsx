"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CalculatorIcon, RefreshCwIcon } from "lucide-react"

export function ClientCalculators({ clientId }: { clientId: string }) {
  const [currentAge, setCurrentAge] = useState(45)
  const [currentIncome, setCurrentIncome] = useState(120000)
  const [currentTaxRate, setCurrentTaxRate] = useState(24)
  const [retirementAge, setRetirementAge] = useState(65)
  const [retirementTaxRate, setRetirementTaxRate] = useState(15)
  const [traditionalIraBalance, setTraditionalIraBalance] = useState(120000)
  const [showResults, setShowResults] = useState(false)
  const [recommendation, setRecommendation] = useState("")

  const calculateRothConversion = () => {
    setShowResults(true)

    // Simple calculation logic for demonstration
    // In a real app, this would be more sophisticated
    if (currentTaxRate < retirementTaxRate) {
      setRecommendation(
        "Based on your current tax rate being lower than your expected retirement tax rate, converting to a Roth IRA now could be beneficial. You'll pay less in taxes now than you would in retirement.",
      )
    } else if (currentTaxRate > retirementTaxRate + 5) {
      setRecommendation(
        "Your current tax rate is significantly higher than your expected retirement tax rate. It may be better to keep your Traditional IRA and pay taxes at the lower rate during retirement.",
      )
    } else {
      setRecommendation(
        "Your current tax rate and expected retirement tax rate are similar. Consider a partial conversion strategy, converting portions of your Traditional IRA to a Roth IRA over several years to spread out the tax burden.",
      )
    }
  }

  const resetCalculator = () => {
    setShowResults(false)
    setRecommendation("")
  }

  return (
    <div className="space-y-6 pt-4">
      <Tabs defaultValue="ira-conversion">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="ira-conversion">IRA to Roth Conversion</TabsTrigger>
          <TabsTrigger value="retirement-income">Retirement Income</TabsTrigger>
          <TabsTrigger value="social-security">Social Security</TabsTrigger>
        </TabsList>

        <TabsContent value="ira-conversion">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CalculatorIcon className="mr-2 h-5 w-5 text-green-600" />
                IRA to Roth IRA Conversion Calculator
              </CardTitle>
              <CardDescription>
                Determine if converting from a Traditional IRA to a Roth IRA makes financial sense based on current and
                future tax rates.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="current-age">Current Age</Label>
                    <Input
                      id="current-age"
                      type="number"
                      value={currentAge}
                      onChange={(e) => setCurrentAge(Number.parseInt(e.target.value))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="retirement-age">Expected Retirement Age</Label>
                    <Input
                      id="retirement-age"
                      type="number"
                      value={retirementAge}
                      onChange={(e) => setRetirementAge(Number.parseInt(e.target.value))}
                    />
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="current-income">Current Annual Income</Label>
                    <Input
                      id="current-income"
                      type="number"
                      value={currentIncome}
                      onChange={(e) => setCurrentIncome(Number.parseInt(e.target.value))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="current-tax-rate">Current Tax Rate (%)</Label>
                    <Input
                      id="current-tax-rate"
                      type="number"
                      value={currentTaxRate}
                      onChange={(e) => setCurrentTaxRate(Number.parseInt(e.target.value))}
                    />
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="traditional-ira-balance">Traditional IRA Balance</Label>
                    <Input
                      id="traditional-ira-balance"
                      type="number"
                      value={traditionalIraBalance}
                      onChange={(e) => setTraditionalIraBalance(Number.parseInt(e.target.value))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="retirement-tax-rate">Expected Retirement Tax Rate (%)</Label>
                    <Input
                      id="retirement-tax-rate"
                      type="number"
                      value={retirementTaxRate}
                      onChange={(e) => setRetirementTaxRate(Number.parseInt(e.target.value))}
                    />
                  </div>
                </div>

                {showResults && (
                  <Card className="bg-muted">
                    <CardHeader>
                      <CardTitle className="text-lg">Recommendation</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p>{recommendation}</p>

                      <div className="mt-4 grid gap-4 md:grid-cols-2">
                        <div>
                          <p className="text-sm font-medium">Tax Due on Conversion</p>
                          <p className="text-xl font-bold">
                            ${Math.round(traditionalIraBalance * (currentTaxRate / 100)).toLocaleString()}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Years Until Retirement</p>
                          <p className="text-xl font-bold">{retirementAge - currentAge}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              {showResults ? (
                <Button variant="outline" onClick={resetCalculator}>
                  <RefreshCwIcon className="mr-2 h-4 w-4" />
                  Reset Calculator
                </Button>
              ) : (
                <div></div>
              )}
              <Button onClick={calculateRothConversion}>Calculate</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="retirement-income">
          <Card>
            <CardHeader>
              <CardTitle>Retirement Income Calculator</CardTitle>
              <CardDescription>
                Calculate your expected retirement income based on your current savings and contributions.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-center text-muted-foreground">This calculator will be available soon.</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="social-security">
          <Card>
            <CardHeader>
              <CardTitle>Social Security Benefits Calculator</CardTitle>
              <CardDescription>
                Estimate your Social Security benefits based on your earnings history and retirement age.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-center text-muted-foreground">This calculator will be available soon.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
