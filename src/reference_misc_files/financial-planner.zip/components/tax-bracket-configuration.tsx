"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { PlusIcon, TrashIcon } from "lucide-react"

interface TaxBracket {
  id: string
  minIncome: number
  maxIncome: number | null
  rate: number
  filingStatus: "single" | "marriedJoint" | "marriedSeparate" | "headOfHousehold"
}

const DEFAULT_TAX_BRACKETS: TaxBracket[] = [
  { id: "1", minIncome: 0, maxIncome: 11000, rate: 10, filingStatus: "single" },
  { id: "2", minIncome: 11001, maxIncome: 44725, rate: 12, filingStatus: "single" },
  { id: "3", minIncome: 44726, maxIncome: 95375, rate: 22, filingStatus: "single" },
  { id: "4", minIncome: 95376, maxIncome: 182050, rate: 24, filingStatus: "single" },
  { id: "5", minIncome: 182051, maxIncome: 231250, rate: 32, filingStatus: "single" },
  { id: "6", minIncome: 231251, maxIncome: 578125, rate: 35, filingStatus: "single" },
  { id: "7", minIncome: 578126, maxIncome: null, rate: 37, filingStatus: "single" },
]

export function TaxBracketConfiguration() {
  const [taxBrackets, setTaxBrackets] = useState<TaxBracket[]>(DEFAULT_TAX_BRACKETS)
  const [selectedFilingStatus, setSelectedFilingStatus] = useState<TaxBracket["filingStatus"]>("single")

  const filteredBrackets = taxBrackets.filter((bracket) => bracket.filingStatus === selectedFilingStatus)

  const addTaxBracket = () => {
    const newBracket: TaxBracket = {
      id: Date.now().toString(),
      minIncome: 0,
      maxIncome: null,
      rate: 0,
      filingStatus: selectedFilingStatus,
    }
    setTaxBrackets([...taxBrackets, newBracket])
  }

  const updateTaxBracket = (id: string, field: keyof TaxBracket, value: any) => {
    setTaxBrackets((brackets) =>
      brackets.map((bracket) => (bracket.id === id ? { ...bracket, [field]: value } : bracket)),
    )
  }

  const deleteTaxBracket = (id: string) => {
    setTaxBrackets((brackets) => brackets.filter((bracket) => bracket.id !== id))
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <Label htmlFor="filing-status">Filing Status</Label>
          <select
            id="filing-status"
            value={selectedFilingStatus}
            onChange={(e) => setSelectedFilingStatus(e.target.value as TaxBracket["filingStatus"])}
            className="w-48 rounded-md border border-input bg-background px-3 py-2"
          >
            <option value="single">Single</option>
            <option value="marriedJoint">Married Filing Jointly</option>
            <option value="marriedSeparate">Married Filing Separately</option>
            <option value="headOfHousehold">Head of Household</option>
          </select>
        </div>
        <Button onClick={addTaxBracket} size="sm">
          <PlusIcon className="mr-2 h-4 w-4" />
          Add Bracket
        </Button>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Min Income</TableHead>
              <TableHead>Max Income</TableHead>
              <TableHead>Tax Rate (%)</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredBrackets.map((bracket) => (
              <TableRow key={bracket.id}>
                <TableCell>
                  <Input
                    type="number"
                    value={bracket.minIncome}
                    onChange={(e) => updateTaxBracket(bracket.id, "minIncome", Number(e.target.value))}
                    className="w-32"
                  />
                </TableCell>
                <TableCell>
                  <Input
                    type="number"
                    value={bracket.maxIncome || ""}
                    onChange={(e) =>
                      updateTaxBracket(bracket.id, "maxIncome", e.target.value ? Number(e.target.value) : null)
                    }
                    placeholder="No limit"
                    className="w-32"
                  />
                </TableCell>
                <TableCell>
                  <Input
                    type="number"
                    step="0.1"
                    value={bracket.rate}
                    onChange={(e) => updateTaxBracket(bracket.id, "rate", Number(e.target.value))}
                    className="w-20"
                  />
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm" onClick={() => deleteTaxBracket(bracket.id)}>
                    <TrashIcon className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {filteredBrackets.length === 0 && (
              <TableRow>
                <TableCell colSpan={4} className="h-24 text-center">
                  No tax brackets configured for this filing status.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <div className="rounded-lg bg-muted p-4">
        <h4 className="font-medium mb-2">Tax Bracket Preview</h4>
        <p className="text-sm text-muted-foreground">
          These tax brackets will be used in all financial calculations and recommendations for your clients. Make sure
          to update them annually or when tax laws change.
        </p>
      </div>
    </div>
  )
}
