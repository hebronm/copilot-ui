"use client"

import { Button } from "./ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu"
import { useToast } from "../hooks/use-toast"
import { BarChart3Icon, LogOutIcon, PlusIcon, UserIcon } from "lucide-react"
import type { NavigationState } from "../App"

interface DashboardHeaderProps {
  navigate: (navigation: NavigationState) => void
  onLogout: () => void
}

export function DashboardHeader({ navigate, onLogout }: DashboardHeaderProps) {
  const { toast } = useToast()

  const handleLogout = () => {
    // In a real app, this would clear the auth token/session
    toast({
      title: "Logged out",
      description: "You have been successfully logged out",
    })
    onLogout()
  }

  return (
    <header className="border-b bg-white">
      <div className="flex h-16 items-center justify-between px-6">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate({ page: "dashboard" })} className="flex items-center gap-2 hover:opacity-80">
            <BarChart3Icon className="h-6 w-6 text-green-600" />
            <span className="text-xl font-bold">Financial Advisor Pro</span>
          </button>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="outline" onClick={() => navigate({ page: "add-client" })}>
            <PlusIcon className="mr-2 h-4 w-4" />
            Add Client
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="rounded-full">
                <UserIcon className="h-5 w-5" />
                <span className="sr-only">User menu</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate({ page: "dashboard" })}>Profile</DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate({ page: "dashboard" })}>Settings</DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate({ page: "configuration" })}>Configuration</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout}>
                <LogOutIcon className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  )
}
