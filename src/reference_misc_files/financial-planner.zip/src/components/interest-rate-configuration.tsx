"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Input } from "./ui/input"
import { Label } from "./ui/label"
import { Textarea } from "./ui/textarea"

export function InterestRateConfiguration() {
  const [rates, setRates] = useState({
    stockMarketReturn: 8.0,
    bondMarketReturn: 4.5,
    savingsAccountRate: 1.5,
    mortgageRate: 6.5,
    inflationRate: 3.0,
    riskFreeRate: 4.0,
  })

  const updateRate = (field: keyof typeof rates, value: number) => {
    setRates((prev) => ({ ...prev, [field]: value }))
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Investment Returns</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="stock-return">Stock Market Return (%)</Label>
              <Input
                id="stock-return"
                type="number"
                step="0.1"
                value={rates.stockMarketReturn}
                onChange={(e) => updateRate("stockMarketReturn", Number(e.target.value))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="bond-return">Bond Market Return (%)</Label>
              <Input
                id="bond-return"
                type="number"
                step="0.1"
                value={rates.bondMarketReturn}
                onChange={(e) => updateRate("bondMarketReturn", Number(e.target.value))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="risk-free-rate">Risk-Free Rate (%)</Label>
              <Input
                id="risk-free-rate"
                type="number"
                step="0.1"
                value={rates.riskFreeRate}
                onChange={(e) => updateRate("riskFreeRate", Number(e.target.value))}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Lending Rates</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="savings-rate">Savings Account Rate (%)</Label>
              <Input
                id="savings-rate"
                type="number"
                step="0.1"
                value={rates.savingsAccountRate}
                onChange={(e) => updateRate("savingsAccountRate", Number(e.target.value))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="mortgage-rate">Average Mortgage Rate (%)</Label>
              <Input
                id="mortgage-rate"
                type="number"
                step="0.1"
                value={rates.mortgageRate}
                onChange={(e) => updateRate("mortgageRate", Number(e.target.value))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="inflation-rate">Inflation Rate (%)</Label>
              <Input
                id="inflation-rate"
                type="number"
                step="0.1"
                value={rates.inflationRate}
                onChange={(e) => updateRate("inflationRate", Number(e.target.value))}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Rate Assumptions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Label htmlFor="rate-notes">Notes and Assumptions</Label>
            <Textarea
              id="rate-notes"
              rows={4}
              placeholder="Add any notes about your rate assumptions, sources, or methodology..."
              defaultValue="Rates based on historical averages and current market conditions. Stock market return assumes diversified portfolio. Update quarterly or as market conditions change."
            />
          </div>
        </CardContent>
      </Card>

      <div className="rounded-lg bg-blue-50 p-4">
        <h4 className="font-medium mb-2 text-blue-900">Rate Configuration Tips</h4>
        <ul className="text-sm text-blue-800 space-y-1">
          <li>• Update rates regularly to reflect current market conditions</li>
          <li>• Consider using conservative estimates for long-term planning</li>
          <li>• Document your sources and methodology for rate assumptions</li>
          <li>• Review and adjust rates at least quarterly</li>
        </ul>
      </div>
    </div>
  )
}
