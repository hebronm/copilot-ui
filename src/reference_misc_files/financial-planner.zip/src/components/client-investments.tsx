import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { HomeIcon, TrendingUpIcon, BarChart3Icon } from "lucide-react"

// Mock data for demonstration
const INVESTMENT_DATA = {
  "1": {
    realEstate: [
      { type: "Primary Residence", value: "$650,000", mortgage: "$320,000", equity: "$330,000" },
      { type: "Rental Property", value: "$350,000", mortgage: "$200,000", equity: "$150,000" },
    ],
    stocks: { value: "$180,000", allocation: "70% stocks, 30% bonds", return: "8.2% (YTD)" },
    other: [
      { type: "Precious Metals", value: "$25,000" },
      { type: "Cryptocurrency", value: "$15,000" },
    ],
  },
  "2": {
    realEstate: [{ type: "Primary Residence", value: "$480,000", mortgage: "$210,000", equity: "$270,000" }],
    stocks: { value: "$120,000", allocation: "60% stocks, 40% bonds", return: "6.8% (YTD)" },
    other: [{ type: "Art Collection", value: "$35,000" }],
  },
  "3": {
    realEstate: [
      { type: "Primary Residence", value: "$850,000", mortgage: "$450,000", equity: "$400,000" },
      { type: "Vacation Home", value: "$550,000", mortgage: "$300,000", equity: "$250,000" },
      { type: "Rental Property", value: "$420,000", mortgage: "$220,000", equity: "$200,000" },
    ],
    stocks: { value: "$450,000", allocation: "75% stocks, 25% bonds", return: "9.1% (YTD)" },
    other: [
      { type: "Private Equity", value: "$150,000" },
      { type: "Cryptocurrency", value: "$75,000" },
    ],
  },
  "4": {
    realEstate: [{ type: "Primary Residence", value: "$620,000", mortgage: "$280,000", equity: "$340,000" }],
    stocks: { value: "$210,000", allocation: "65% stocks, 35% bonds", return: "7.5% (YTD)" },
    other: [{ type: "Collectibles", value: "$30,000" }],
  },
  "5": {
    realEstate: [
      { type: "Primary Residence", value: "$1,200,000", mortgage: "$520,000", equity: "$680,000" },
      { type: "Commercial Property", value: "$1,800,000", mortgage: "$900,000", equity: "$900,000" },
    ],
    stocks: { value: "$850,000", allocation: "80% stocks, 20% bonds", return: "10.2% (YTD)" },
    other: [
      { type: "Business Ownership", value: "$1,200,000" },
      { type: "Private Equity", value: "$250,000" },
      { type: "Art Collection", value: "$120,000" },
    ],
  },
}

export function ClientInvestments({ clientId }: { clientId: string }) {
  const investments = INVESTMENT_DATA[clientId as keyof typeof INVESTMENT_DATA] || INVESTMENT_DATA["1"]

  return (
    <div className="space-y-6 pt-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <HomeIcon className="mr-2 h-5 w-5 text-green-600" />
            Real Estate Investments
          </CardTitle>
        </CardHeader>
        <CardContent>
          {investments.realEstate.length > 0 ? (
            <div className="space-y-6">
              {investments.realEstate.map((property, index) => (
                <div key={index} className="rounded-lg border p-4">
                  <h3 className="mb-2 font-semibold">{property.type}</h3>
                  <div className="grid gap-2 md:grid-cols-3">
                    <div>
                      <p className="text-sm text-muted-foreground">Property Value</p>
                      <p className="font-medium">{property.value}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Mortgage Balance</p>
                      <p className="font-medium">{property.mortgage}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Equity</p>
                      <p className="font-medium">{property.equity}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground">No real estate investments recorded.</p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUpIcon className="mr-2 h-5 w-5 text-green-600" />
            Stocks & Bonds
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-lg border p-4">
            <div className="grid gap-4 md:grid-cols-3">
              <div>
                <p className="text-sm text-muted-foreground">Total Value</p>
                <p className="font-medium">{investments.stocks.value}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Asset Allocation</p>
                <p className="font-medium">{investments.stocks.allocation}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Return</p>
                <p className="font-medium">{investments.stocks.return}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart3Icon className="mr-2 h-5 w-5 text-green-600" />
            Other Investments
          </CardTitle>
        </CardHeader>
        <CardContent>
          {investments.other.length > 0 ? (
            <div className="space-y-4">
              {investments.other.map((item, index) => (
                <div key={index} className="flex justify-between rounded-lg border p-4">
                  <p className="font-medium">{item.type}</p>
                  <p className="font-medium">{item.value}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground">No other investments recorded.</p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
