"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Input } from "./ui/input"
import { Label } from "./ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table"

export function RetirementConfiguration() {
  const [contributionLimits, setContributionLimits] = useState({
    "401k": { under50: 23000, over50: 30500 },
    traditionalIRA: { under50: 7000, over50: 8000 },
    rothIRA: { under50: 7000, over50: 8000 },
    sep: { under50: 69000, over50: 69000 },
    simple: { under50: 16000, over50: 19500 },
  })

  const [socialSecuritySettings, setSocialSecuritySettings] = useState({
    fullRetirementAge: 67,
    earlyRetirementAge: 62,
    maxBenefitAge: 70,
    earlyRetirementReduction: 25,
    delayedRetirementCredit: 8,
    maxTaxableWages: 160200,
  })

  const updateContributionLimit = (
    account: keyof typeof contributionLimits,
    ageGroup: "under50" | "over50",
    value: number,
  ) => {
    setContributionLimits((prev) => ({
      ...prev,
      [account]: {
        ...prev[account],
        [ageGroup]: value,
      },
    }))
  }

  const updateSocialSecuritySetting = (field: keyof typeof socialSecuritySettings, value: number) => {
    setSocialSecuritySettings((prev) => ({ ...prev, [field]: value }))
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Annual Contribution Limits (2024)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Account Type</TableHead>
                  <TableHead>Under 50</TableHead>
                  <TableHead>50 and Over</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium">401(k)</TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      value={contributionLimits["401k"].under50}
                      onChange={(e) => updateContributionLimit("401k", "under50", Number(e.target.value))}
                      className="w-32"
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      value={contributionLimits["401k"].over50}
                      onChange={(e) => updateContributionLimit("401k", "over50", Number(e.target.value))}
                      className="w-32"
                    />
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Traditional IRA</TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      value={contributionLimits.traditionalIRA.under50}
                      onChange={(e) => updateContributionLimit("traditionalIRA", "under50", Number(e.target.value))}
                      className="w-32"
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      value={contributionLimits.traditionalIRA.over50}
                      onChange={(e) => updateContributionLimit("traditionalIRA", "over50", Number(e.target.value))}
                      className="w-32"
                    />
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Roth IRA</TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      value={contributionLimits.rothIRA.under50}
                      onChange={(e) => updateContributionLimit("rothIRA", "under50", Number(e.target.value))}
                      className="w-32"
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      value={contributionLimits.rothIRA.over50}
                      onChange={(e) => updateContributionLimit("rothIRA", "over50", Number(e.target.value))}
                      className="w-32"
                    />
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">SEP-IRA</TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      value={contributionLimits.sep.under50}
                      onChange={(e) => updateContributionLimit("sep", "under50", Number(e.target.value))}
                      className="w-32"
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      value={contributionLimits.sep.over50}
                      onChange={(e) => updateContributionLimit("sep", "over50", Number(e.target.value))}
                      className="w-32"
                    />
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">SIMPLE IRA</TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      value={contributionLimits.simple.under50}
                      onChange={(e) => updateContributionLimit("simple", "under50", Number(e.target.value))}
                      className="w-32"
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      value={contributionLimits.simple.over50}
                      onChange={(e) => updateContributionLimit("simple", "over50", Number(e.target.value))}
                      className="w-32"
                    />
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Social Security Configuration</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="full-retirement-age">Full Retirement Age</Label>
              <Input
                id="full-retirement-age"
                type="number"
                value={socialSecuritySettings.fullRetirementAge}
                onChange={(e) => updateSocialSecuritySetting("fullRetirementAge", Number(e.target.value))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="early-retirement-age">Early Retirement Age</Label>
              <Input
                id="early-retirement-age"
                type="number"
                value={socialSecuritySettings.earlyRetirementAge}
                onChange={(e) => updateSocialSecuritySetting("earlyRetirementAge", Number(e.target.value))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="max-benefit-age">Maximum Benefit Age</Label>
              <Input
                id="max-benefit-age"
                type="number"
                value={socialSecuritySettings.maxBenefitAge}
                onChange={(e) => updateSocialSecuritySetting("maxBenefitAge", Number(e.target.value))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="early-reduction">Early Retirement Reduction (%)</Label>
              <Input
                id="early-reduction"
                type="number"
                step="0.1"
                value={socialSecuritySettings.earlyRetirementReduction}
                onChange={(e) => updateSocialSecuritySetting("earlyRetirementReduction", Number(e.target.value))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="delayed-credit">Delayed Retirement Credit (% per year)</Label>
              <Input
                id="delayed-credit"
                type="number"
                step="0.1"
                value={socialSecuritySettings.delayedRetirementCredit}
                onChange={(e) => updateSocialSecuritySetting("delayedRetirementCredit", Number(e.target.value))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="max-taxable-wages">Maximum Taxable Wages</Label>
              <Input
                id="max-taxable-wages"
                type="number"
                value={socialSecuritySettings.maxTaxableWages}
                onChange={(e) => updateSocialSecuritySetting("maxTaxableWages", Number(e.target.value))}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="rounded-lg bg-green-50 p-4">
        <h4 className="font-medium mb-2 text-green-900">Annual Updates Required</h4>
        <p className="text-sm text-green-800">
          Retirement contribution limits and Social Security parameters are updated annually by the IRS and SSA. Make
          sure to review and update these values each year, typically announced in October/November for the following
          year.
        </p>
      </div>
    </div>
  )
}
