"use client"

import { useState } from "react"
import { Button } from "./ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Input } from "./ui/input"
import { Label } from "./ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import { useToast } from "../hooks/use-toast"
import { TaxBracketConfiguration } from "./tax-bracket-configuration"
import { InterestRateConfiguration } from "./interest-rate-configuration"
import { RetirementConfiguration } from "./retirement-configuration"
import { CalculatorIcon, DollarSignIcon, TrendingUpIcon, CalendarIcon } from "lucide-react"

export function ConfigurationTabs() {
  const { toast } = useToast()
  const [isSaving, setIsSaving] = useState(false)

  const handleSaveConfiguration = async () => {
    setIsSaving(true)
    try {
      // In a real app, this would save to a database
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Configuration saved",
        description: "Your global settings have been updated successfully",
      })
    } catch (error) {
      toast({
        title: "Error saving configuration",
        description: "There was a problem saving your settings. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="tax-brackets" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="tax-brackets">Tax Brackets</TabsTrigger>
          <TabsTrigger value="interest-rates">Interest Rates</TabsTrigger>
          <TabsTrigger value="retirement">Retirement</TabsTrigger>
          <TabsTrigger value="general">General</TabsTrigger>
        </TabsList>

        <TabsContent value="tax-brackets">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <DollarSignIcon className="mr-2 h-5 w-5 text-green-600" />
                Tax Bracket Configuration
              </CardTitle>
              <CardDescription>
                Set up current year federal tax brackets for accurate financial planning calculations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <TaxBracketConfiguration />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="interest-rates">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUpIcon className="mr-2 h-5 w-5 text-green-600" />
                Interest Rate Configuration
              </CardTitle>
              <CardDescription>
                Configure default interest rates and market assumptions for calculations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <InterestRateConfiguration />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="retirement">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CalendarIcon className="mr-2 h-5 w-5 text-green-600" />
                Retirement Configuration
              </CardTitle>
              <CardDescription>Set default retirement planning parameters and contribution limits</CardDescription>
            </CardHeader>
            <CardContent>
              <RetirementConfiguration />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CalculatorIcon className="mr-2 h-5 w-5 text-green-600" />
                General Configuration
              </CardTitle>
              <CardDescription>Configure general application settings and default values</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="current-year">Current Tax Year</Label>
                    <Input id="current-year" type="number" defaultValue={2024} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="inflation-rate">Default Inflation Rate (%)</Label>
                    <Input id="inflation-rate" type="number" step="0.1" defaultValue={3.0} />
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="default-retirement-age">Default Retirement Age</Label>
                    <Input id="default-retirement-age" type="number" defaultValue={65} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="life-expectancy">Default Life Expectancy</Label>
                    <Input id="life-expectancy" type="number" defaultValue={85} />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="firm-name">Firm Name</Label>
                  <Input id="firm-name" defaultValue="Financial Advisor Pro" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end">
        <Button onClick={handleSaveConfiguration} disabled={isSaving}>
          {isSaving ? "Saving..." : "Save Configuration"}
        </Button>
      </div>
    </div>
  )
}
