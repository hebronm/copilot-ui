import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Progress } from "./ui/progress"
import { PiggyBankIcon, TrendingUpIcon, CalendarIcon } from "lucide-react"

// Mock data for demonstration
const RETIREMENT_DATA = {
  "1": {
    targetAge: 65,
    currentAge: 45,
    targetMonthlyIncome: "$8,000",
    projectedMonthlyIncome: "$6,500",
    progressPercentage: 81,
    accounts: {
      "401k": { balance: "$450,000", annualContribution: "$19,500", employerMatch: "5%" },
      traditionalIRA: { balance: "$120,000", annualContribution: "$6,000", employerMatch: "N/A" },
      rothIRA: { balance: "$0", annualContribution: "$0", employerMatch: "N/A" },
    },
    recommendations: [
      "Consider increasing 401(k) contributions to the maximum allowed",
      "Evaluate converting Traditional IRA to Roth IRA given current tax bracket",
      "Review asset allocation to ensure it aligns with retirement timeline",
    ],
  },
  "2": {
    targetAge: 62,
    currentAge: 38,
    targetMonthlyIncome: "$6,000",
    projectedMonthlyIncome: "$4,200",
    progressPercentage: 70,
    accounts: {
      "401k": { balance: "$280,000", annualContribution: "$15,000", employerMatch: "4%" },
      traditionalIRA: { balance: "$85,000", annualContribution: "$6,000", employerMatch: "N/A" },
      rothIRA: { balance: "$45,000", annualContribution: "$2,000", employerMatch: "N/A" },
    },
    recommendations: [
      "Increase Roth IRA contributions to the maximum allowed",
      "Consider diversifying retirement accounts for tax advantages",
      "Review investment strategy for potentially higher returns",
    ],
  },
  "3": {
    targetAge: 67,
    currentAge: 52,
    targetMonthlyIncome: "$12,000",
    projectedMonthlyIncome: "$10,800",
    progressPercentage: 90,
    accounts: {
      "401k": { balance: "$950,000", annualContribution: "$27,000", employerMatch: "6%" },
      traditionalIRA: { balance: "$350,000", annualContribution: "$7,000", employerMatch: "N/A" },
      rothIRA: { balance: "$120,000", annualContribution: "$7,000", employerMatch: "N/A" },
    },
    recommendations: [
      "Consider catch-up contributions to maximize tax-advantaged savings",
      "Evaluate asset allocation to potentially reduce risk as retirement approaches",
      "Develop a withdrawal strategy to minimize taxes in retirement",
    ],
  },
  "4": {
    targetAge: 65,
    currentAge: 41,
    targetMonthlyIncome: "$9,000",
    projectedMonthlyIncome: "$7,200",
    progressPercentage: 80,
    accounts: {
      "401k": { balance: "$380,000", annualContribution: "$20,500", employerMatch: "5%" },
      traditionalIRA: { balance: "$110,000", annualContribution: "$6,000", employerMatch: "N/A" },
      rothIRA: { balance: "$75,000", annualContribution: "$6,000", employerMatch: "N/A" },
    },
    recommendations: [
      "Maintain current contribution levels to stay on track",
      "Consider Roth conversion ladder strategy for tax efficiency",
      "Review investment fees to maximize returns",
    ],
  },
  "5": {
    targetAge: 70,
    currentAge: 60,
    targetMonthlyIncome: "$15,000",
    projectedMonthlyIncome: "$16,200",
    progressPercentage: 108,
    accounts: {
      "401k": { balance: "$1,800,000", annualContribution: "$27,000", employerMatch: "4%" },
      traditionalIRA: { balance: "$650,000", annualContribution: "$7,000", employerMatch: "N/A" },
      rothIRA: { balance: "$350,000", annualContribution: "$7,000", employerMatch: "N/A" },
    },
    recommendations: [
      "Begin planning withdrawal strategy to minimize taxes",
      "Consider Qualified Charitable Distributions to reduce RMDs",
      "Evaluate long-term care insurance options",
    ],
  },
}

export function ClientRetirement({ clientId }: { clientId: string }) {
  const retirement = RETIREMENT_DATA[clientId as keyof typeof RETIREMENT_DATA] || RETIREMENT_DATA["1"]

  return (
    <div className="space-y-6 pt-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <CalendarIcon className="mr-2 h-5 w-5 text-green-600" />
            Retirement Overview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground">Current Age</p>
                <p className="text-2xl font-bold">{retirement.currentAge}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Target Retirement Age</p>
                <p className="text-2xl font-bold">{retirement.targetAge}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Years Until Retirement</p>
                <p className="text-2xl font-bold">{retirement.targetAge - retirement.currentAge}</p>
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground">Target Monthly Income</p>
                <p className="text-2xl font-bold">{retirement.targetMonthlyIncome}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Projected Monthly Income</p>
                <p className="text-2xl font-bold">{retirement.projectedMonthlyIncome}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Progress Toward Goal</p>
                <div className="mt-2 space-y-2">
                  <Progress value={retirement.progressPercentage} className="h-2" />
                  <p className="text-right text-sm">{retirement.progressPercentage}%</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <PiggyBankIcon className="mr-2 h-5 w-5 text-green-600" />
            Retirement Accounts
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="rounded-lg border p-4">
              <h3 className="mb-4 font-semibold">401(k)</h3>
              <div className="grid gap-4 md:grid-cols-3">
                <div>
                  <p className="text-sm text-muted-foreground">Current Balance</p>
                  <p className="font-medium">{retirement.accounts["401k"].balance}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Annual Contribution</p>
                  <p className="font-medium">{retirement.accounts["401k"].annualContribution}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Employer Match</p>
                  <p className="font-medium">{retirement.accounts["401k"].employerMatch}</p>
                </div>
              </div>
            </div>

            <div className="rounded-lg border p-4">
              <h3 className="mb-4 font-semibold">Traditional IRA</h3>
              <div className="grid gap-4 md:grid-cols-3">
                <div>
                  <p className="text-sm text-muted-foreground">Current Balance</p>
                  <p className="font-medium">{retirement.accounts["traditionalIRA"].balance}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Annual Contribution</p>
                  <p className="font-medium">{retirement.accounts["traditionalIRA"].annualContribution}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Employer Match</p>
                  <p className="font-medium">{retirement.accounts["traditionalIRA"].employerMatch}</p>
                </div>
              </div>
            </div>

            <div className="rounded-lg border p-4">
              <h3 className="mb-4 font-semibold">Roth IRA</h3>
              <div className="grid gap-4 md:grid-cols-3">
                <div>
                  <p className="text-sm text-muted-foreground">Current Balance</p>
                  <p className="font-medium">{retirement.accounts["rothIRA"].balance}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Annual Contribution</p>
                  <p className="font-medium">{retirement.accounts["rothIRA"].annualContribution}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Employer Match</p>
                  <p className="font-medium">{retirement.accounts["rothIRA"].employerMatch}</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUpIcon className="mr-2 h-5 w-5 text-green-600" />
            Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {retirement.recommendations.map((recommendation, index) => (
              <li key={index} className="flex items-start">
                <span className="mr-2 flex h-5 w-5 items-center justify-center rounded-full bg-green-100 text-xs text-green-600">
                  {index + 1}
                </span>
                <span>{recommendation}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}
