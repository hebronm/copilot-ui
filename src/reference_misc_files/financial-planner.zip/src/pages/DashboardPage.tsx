import { ClientList } from "../components/client-list"
import { DashboardHeader } from "../components/dashboard-header"
import { DashboardStats } from "../components/dashboard-stats"
import type { NavigationState } from "../App"

interface DashboardPageProps {
  navigate: (navigation: NavigationState) => void
  onLogout: () => void
}

export default function DashboardPage({ navigate, onLogout }: DashboardPageProps) {
  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader navigate={navigate} onLogout={onLogout} />
      <main className="flex-1 space-y-6 p-6">
        <DashboardStats />
        <ClientList navigate={navigate} />
      </main>
    </div>
  )
}
