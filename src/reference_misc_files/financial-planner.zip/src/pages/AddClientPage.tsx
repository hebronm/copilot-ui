"use client"

import { AddClientForm } from "../components/add-client-form"
import { DashboardHeader } from "../components/dashboard-header"
import { Button } from "../components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card"
import { ArrowLeftIcon } from "lucide-react"
import type { NavigationState } from "../App"

interface AddClientPageProps {
  navigate: (navigation: NavigationState) => void
  onLogout: () => void
}

export default function AddClientPage({ navigate, onLogout }: AddClientPageProps) {
  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader navigate={navigate} onLogout={onLogout} />
      <main className="flex-1 p-6">
        <div className="mx-auto max-w-4xl">
          <div className="mb-6">
            <Button variant="ghost" size="sm" onClick={() => navigate({ page: "dashboard" })}>
              <ArrowLeftIcon className="mr-2 h-4 w-4" />
              Back to Dashboard
            </Button>
          </div>
          <Card>
            <CardHeader>
              <CardTitle>Add New Client</CardTitle>
              <CardDescription>Enter your client's information to create a new profile</CardDescription>
            </CardHeader>
            <CardContent>
              <AddClientForm navigate={navigate} />
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
