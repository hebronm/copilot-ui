"use client"

import { useState } from "react"
import { Toaster } from "./components/ui/toaster"
import LoginPage from "./pages/LoginPage"
import DashboardPage from "./pages/DashboardPage"
import AddClientPage from "./pages/AddClientPage"
import ClientDetailPage from "./pages/ClientDetailPage"
import ConfigurationPage from "./pages/ConfigurationPage"
import { ThemeProvider } from "./components/theme-provider"

export type NavigationState = {
  page: "login" | "dashboard" | "add-client" | "client-detail" | "configuration"
  clientId?: string
}

function App() {
  const [navigation, setNavigation] = useState<NavigationState>({ page: "login" })
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  const navigate = (newNavigation: NavigationState) => {
    setNavigation(newNavigation)
  }

  const handleLogin = () => {
    setIsAuthenticated(true)
    setNavigation({ page: "dashboard" })
  }

  const handleLogout = () => {
    setIsAuthenticated(false)
    setNavigation({ page: "login" })
  }

  const renderPage = () => {
    if (!isAuthenticated && navigation.page !== "login") {
      return <LoginPage onLogin={handleLogin} navigate={navigate} />
    }

    switch (navigation.page) {
      case "login":
        return <LoginPage onLogin={handleLogin} navigate={navigate} />
      case "dashboard":
        return <DashboardPage navigate={navigate} onLogout={handleLogout} />
      case "add-client":
        return <AddClientPage navigate={navigate} onLogout={handleLogout} />
      case "client-detail":
        return <ClientDetailPage clientId={navigation.clientId || "1"} navigate={navigate} onLogout={handleLogout} />
      case "configuration":
        return <ConfigurationPage navigate={navigate} onLogout={handleLogout} />
      default:
        return <LoginPage onLogin={handleLogin} navigate={navigate} />
    }
  }

  return (
    <ThemeProvider defaultTheme="light" storageKey="financial-planner-theme">
      {renderPage()}
      <Toaster />
    </ThemeProvider>
  )
}

export default App
