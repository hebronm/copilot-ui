import { ConfigurationTabs } from "@/components/configuration-tabs"
import { DashboardHeader } from "@/components/dashboard-header"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeftIcon, SettingsIcon } from "lucide-react"
import Link from "next/link"

export default function ConfigurationPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader />
      <main className="flex-1 p-6">
        <div className="mx-auto max-w-6xl">
          <div className="mb-6 flex items-center justify-between">
            <Button asChild variant="ghost" size="sm">
              <Link href="/dashboard">
                <ArrowLeftIcon className="mr-2 h-4 w-4" />
                Back to Dashboard
              </Link>
            </Button>
          </div>

          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-100">
                  <SettingsIcon className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <CardTitle>Global Configuration</CardTitle>
                  <CardDescription>
                    Configure settings that apply to all clients and financial calculations
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
          </Card>

          <ConfigurationTabs />
        </div>
      </main>
    </div>
  )
}
