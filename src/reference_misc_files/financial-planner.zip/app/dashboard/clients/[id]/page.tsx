import Link from "next/link"
import { DashboardHeader } from "@/components/dashboard-header"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeftIcon, UserIcon } from "lucide-react"
import { ClientOverview } from "@/components/client-overview"
import { ClientInvestments } from "@/components/client-investments"
import { ClientRetirement } from "@/components/client-retirement"
import { ClientCalculators } from "@/components/client-calculators"

export default function ClientDetailPage({ params }: { params: { id: string } }) {
  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader />
      <main className="flex-1 p-6">
        <div className="mx-auto max-w-6xl">
          <div className="mb-6 flex items-center justify-between">
            <Button asChild variant="ghost" size="sm">
              <Link href="/dashboard">
                <ArrowLeftIcon className="mr-2 h-4 w-4" />
                Back to Clients
              </Link>
            </Button>
            <div className="flex gap-2">
              <Button variant="outline">Edit Client</Button>
              <Button>Schedule Meeting</Button>
            </div>
          </div>

          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-green-100">
                  <UserIcon className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <CardTitle>
                    {params.id === "1"
                      ? "John Smith"
                      : params.id === "2"
                        ? "Sarah Johnson"
                        : params.id === "3"
                          ? "Michael Brown"
                          : params.id === "4"
                            ? "Emily Davis"
                            : "Robert Wilson"}
                  </CardTitle>
                  <CardDescription>
                    {params.id === "1"
                      ? "john.smith@example.com"
                      : params.id === "2"
                        ? "sarah.j@example.com"
                        : params.id === "3"
                          ? "m.brown@example.com"
                          : params.id === "4"
                            ? "emily.d@example.com"
                            : "r.wilson@example.com"}
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
          </Card>

          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="investments">Investments</TabsTrigger>
              <TabsTrigger value="retirement">Retirement</TabsTrigger>
              <TabsTrigger value="calculators">Calculators</TabsTrigger>
            </TabsList>

            <TabsContent value="overview">
              <ClientOverview clientId={params.id} />
            </TabsContent>

            <TabsContent value="investments">
              <ClientInvestments clientId={params.id} />
            </TabsContent>

            <TabsContent value="retirement">
              <ClientRetirement clientId={params.id} />
            </TabsContent>

            <TabsContent value="calculators">
              <ClientCalculators clientId={params.id} />
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
