import { LoginForm } from "@/components/login-form"

export default function Home() {
  // In a real app, we would check if the user is already authenticated
  // and redirect them to the dashboard if they are

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gray-50">
      <div className="w-full max-w-md space-y-8 rounded-lg bg-white p-8 shadow-md">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900">Financial Advisor Pro</h1>
          <p className="mt-2 text-sm text-gray-600">Sign in to access your client portfolio</p>
        </div>
        <LoginForm />
      </div>
    </div>
  )
}
